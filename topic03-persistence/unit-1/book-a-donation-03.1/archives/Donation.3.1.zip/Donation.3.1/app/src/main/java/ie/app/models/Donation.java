package ie.app.models;

import java.util.Random;

public class Donation
{
    public long   id;
    public int    amount;
    public String method;

    public Donation (int amount, String method)
    {
        this.id = unsignedLong();
        this.amount = amount;
        this.method = method;
    }

    @Override
    public String toString() {
        return "Donation{" +
                "id= " + id +
                "amount=$" + amount +
                ", method='" + method + '\'' +
                '}';
    }

    /**
     * Generate a long greater than zero
     * @return Unsigned Long value greater than zero
     */
    private Long unsignedLong() {
        long rndVal = 0;
        do {
            rndVal = new Random().nextLong();
        } while (rndVal <= 0);
        return rndVal;
    }
}
