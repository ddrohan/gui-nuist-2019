package ie.app.activities;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TimePicker;

import ie.app.R;

public class ShowTime extends Base {

  EditText etChooseTime;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_showtime);

    etChooseTime = findViewById(R.id.etChooseTime);

  }

  public void chooseTime(View view)
  {
    TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
      @Override
      public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
        //Set you Time Variables here

        etChooseTime.setText(String.format("%02d:%02d", hourOfDay, minutes));
      }
    }, 12, 30, true);

    timePickerDialog.show();

  }
}
